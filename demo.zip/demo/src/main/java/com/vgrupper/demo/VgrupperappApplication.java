package com.vgrupper.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VgrupperappApplication {

	public static void main(String[] args) {
		SpringApplication.run(VgrupperappApplication.class, args);
	}

}
